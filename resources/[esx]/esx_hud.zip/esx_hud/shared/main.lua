HUD = {}
HUD.Data = {
    OnlinePlayers = 0,
    Weapon = {},
    Money = {},
}
